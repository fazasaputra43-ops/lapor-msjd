# Lapor Mas Jod

Website prototipe wadah aspirasi siswa SMA N 1 Karanganom.

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser.
3. Isi formulir dan kirim laporan.

## Catatan penting
Versi ini menggunakan `localStorage`, sehingga laporan tersimpan di browser/perangkat yang digunakan. Ini cocok untuk demo atau prototipe, tetapi **belum cocok sebagai sistem sekolah yang dipakai bersama**.

Untuk versi produksi, pindahkan penyimpanan ke backend/database (misalnya Supabase/Firebase/MySQL) dan tambahkan login admin agar laporan tersimpan terpusat serta aman.

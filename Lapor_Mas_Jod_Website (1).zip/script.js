const KEY="laporMasJodReports";
const form=document.getElementById("reportForm");
const keluhan=document.getElementById("keluhan");
const count=document.getElementById("count");
const bukti=document.getElementById("bukti");

keluhan.addEventListener("input",()=>count.textContent=keluhan.value.length);

function getReports(){return JSON.parse(localStorage.getItem(KEY)||"[]")}
function saveReports(data){localStorage.setItem(KEY,JSON.stringify(data))}

function makeId(){
  const d=new Date();
  return "LMJ-"+d.getFullYear()+String(d.getMonth()+1).padStart(2,"0")+String(d.getDate()).padStart(2,"0")+"-"+Math.random().toString(36).slice(2,7).toUpperCase();
}

function escapeHTML(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

form.addEventListener("submit",async e=>{
  e.preventDefault();
  const file=bukti.files[0];
  if(file && (!file.type.startsWith("image/") || file.size>5*1024*1024)){
    alert("Bukti harus berupa gambar dengan ukuran maksimal 5 MB.");
    return;
  }
  let image="";
  if(file){
    image=await new Promise((resolve,reject)=>{
      const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(file);
    });
  }
  const report={
    id:makeId(),
    date:new Date().toLocaleString("id-ID"),
    kelas:document.getElementById("kelas").value,
    nama:document.getElementById("nama").value.trim(),
    kategori:document.getElementById("kategori").value,
    keluhan:keluhan.value.trim(),
    image,
    status:"Diterima"
  };
  const reports=getReports();
  reports.unshift(report);
  saveReports(reports);
  form.reset(); count.textContent="0";
  document.getElementById("reportId").textContent=report.id;
  document.getElementById("success").classList.remove("hidden");
  renderReports();
  window.scrollTo({top:document.getElementById("success").offsetTop-30,behavior:"smooth"});
});

function renderReports(){
  const reports=getReports();
  const box=document.getElementById("reports");
  const statCats=["Semua","KBM","Sarana & Prasarana","Lingkungan"];
  document.getElementById("stats").innerHTML=statCats.map(c=>{
    const n=c==="Semua"?reports.length:reports.filter(r=>r.kategori===c).length;
    return `<div class="stat"><b>${n}</b><span>${c}</span></div>`;
  }).join("");
  if(!reports.length){box.innerHTML='<div class="empty">Belum ada laporan tersimpan.</div>';return}
  box.innerHTML=reports.map(r=>`
    <article class="report">
      <div class="report-top">
        <strong>${escapeHTML(r.id)}</strong><span class="pill">${escapeHTML(r.status)}</span>
      </div>
      <div class="report-meta">${escapeHTML(r.date)} · Kelas ${escapeHTML(r.kelas)} · ${escapeHTML(r.kategori)} · ${r.nama?escapeHTML(r.nama):"Anonim"}</div>
      <p>${escapeHTML(r.keluhan).replace(/\n/g,"<br>")}</p>
      ${r.image?`<details><summary>Lihat bukti</summary><img src="${r.image}" alt="Bukti laporan" style="max-width:100%;max-height:320px;border-radius:10px;margin-top:10px"></details>`:""}
    </article>`).join("");
}

document.getElementById("exportBtn").addEventListener("click",()=>{
  const reports=getReports();
  if(!reports.length){alert("Belum ada laporan untuk diekspor.");return}
  const rows=[
    ["ID","Tanggal","Kelas","Nama","Kategori","Keluhan","Status"],
    ...reports.map(r=>[r.id,r.date,r.kelas,r.nama||"Anonim",r.kategori,r.keluhan,r.status])
  ];
  const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
  const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="laporan-lapor-mas-jod.csv";a.click();
  URL.revokeObjectURL(a.href);
});

renderReports();
